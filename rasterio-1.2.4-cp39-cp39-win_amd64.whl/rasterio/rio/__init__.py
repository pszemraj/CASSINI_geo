"""
Rasterio commandline interface components
"""
